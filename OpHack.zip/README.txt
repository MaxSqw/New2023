>| Unzip the archive | Password: OPHACK
>| Disable the antivirus
>| Run autoinstall.bat or OPHack.exe
>| Select the installation location
>| Run OpHack
>| Enjoy your game