>| Unzip the archive
>| Disable the antivirus
>| Run autoinstall.bat or OPHack.exe
>| Select the installation location
>| Run OpHack
>| Enjoy your game